package hql;
import java.util.*;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try
{ 
	 SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	 Session session = sessionFactory.openSession();
     Transaction t;
     t=session.beginTransaction();
     
//Insert into the table Employee
/* 
     Employee ob=new Employee();
     	ob.setEno(104);
     	ob.setEname("hari");
     	ob.setSal(20000);
     	ob.setCity("hyderabad");
     
     Employee ob1=new Employee();
     	ob1.setEno(105);
     	ob1.setEname("harish");
     	ob1.setSal(20400);
     	ob1.setCity("Hyderabad");
     
     session.save(ob1);   
     session.save(ob);
     t.commit();
     */
     
//retrieving all the employee
  
     /*
     String hql = "FROM Employee";
     Query query = session.createQuery(hql);
     List <Employee> results = query.list();
     System.out.println(results);
	*/
     
//retrieving with alias name
     /*
     String hql = "SELECT E.ename FROM Employee E";
     Query query = session.createQuery(hql);
     List results = query.list();
          System.out.println(results);
      */
 //Where clause         
    /*
     	String hql = "FROM Employee E WHERE E.eno=101";
          Query query = session.createQuery(hql);
          List results = query.list();
               System.out.println(results);
     */
//order by
/*     
     String hql = "FROM Employee E WHERE E.eno > 4 ORDER BY E.sal DESC";
     Query query = session.createQuery(hql);
     List results = query.list();  
   System.out.println(results);
*/
//Aggregate function
/*     
     String hql = "SELECT count(distinct E.ename) FROM Employee E";
     Query query = session.createQuery(hql);
     List results = query.list();
     System.out.println(results);
  */
// Aggregate function
/*     
     String hql = "SELECT sum(E.sal) FROM Employee E";
     Query query = session.createQuery(hql);
     List results = query.list();
     System.out.println(results);
  */   
//Named Parameters
/*    
     String hql = "FROM Employee E WHERE E.eno = :employee_id";
     Query query = session.createQuery(hql);
     query.setParameter("employee_id",101);
     List results = query.list();
   System.out.println(results);
*/

 //update the table 
/*
     t=session.beginTransaction();
         String hib = "UPDATE Employee set ename=:n WHERE eno=:i";
     Query q=session.createQuery(hib);  
     q.setParameter("n","Ramesh");  
     q.setParameter("i",101);  
     int status=q.executeUpdate();  
     System.out.println(status); 
t.commit();
*/   
//delete
/*
     t=session.beginTransaction();

     String hib = "DELETE FROM Employee where eno=105";
     Query query=session.createQuery(hib);  
     query.executeUpdate();
     t.commit();
*/     
     
     
    
}
finally {}
    	 }
     }
    	 